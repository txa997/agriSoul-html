/**
 * Minified by jsDelivr using Terser v5.39.0.
 * Original file: /npm/@phosphor-icons/web@2.1.2/src/index.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */
var head=document.getElementsByTagName("head")[0];for(const e of["regular","thin","light","bold","fill","duotone"]){var link=document.createElement("link");link.rel="stylesheet",link.type="text/css",link.href=`https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2.1.2/src/${e}/style.css`,head.appendChild(link)}
//# sourceMappingURL=/sm/350a179ddbde87d7036fd1e83d7a3048a3dc9382271c868ac62ea7d80c77f5ce.map